export default {
    default: '--format-options \'{"snippetInterface": "synchronous"}\'',
    import: ['./UI/support/**/*.js', './API/support/**/*.js']
};
